---
name: Canopy & Cool
colors:
  surface: '#e9ffec'
  surface-dim: '#c5e1cb'
  surface-bright: '#e9ffec'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#dffbe4'
  surface-container: '#d9f5df'
  surface-container-high: '#d3efd9'
  surface-container-highest: '#cee9d4'
  on-surface: '#082013'
  on-surface-variant: '#404942'
  inverse-surface: '#1e3527'
  inverse-on-surface: '#dcf8e1'
  outline: '#707971'
  outline-variant: '#c0c9c0'
  surface-tint: '#2d6a48'
  primary: '#003820'
  on-primary: '#ffffff'
  primary-container: '#0f5132'
  on-primary-container: '#84c39b'
  inverse-primary: '#95d4ac'
  secondary: '#00677c'
  on-secondary: '#ffffff'
  secondary-container: '#33d7fe'
  on-secondary-container: '#005b6d'
  tertiary: '#472a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#653e00'
  on-tertiary-container: '#faa213'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f1c7'
  primary-fixed-dim: '#95d4ac'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#0f5132'
  secondary-fixed: '#b1ecff'
  secondary-fixed-dim: '#33d7fe'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5e'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#e9ffec'
  on-background: '#082013'
  surface-variant: '#cee9d4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system is engineered for pedestrian thermal well-being, sensory comfort, and climate-aware urban mobility. It unites environmental intelligence with microclimate data, steering pedestrians away from concrete heat islands into shaded corridors, tree canopies, and refreshing misting zones.

### Aesthetic Movement
Modern Ecological Functionalism with Tactile Glassmorphism. The visual tone is crisp, calming, and restorative—offering an immediate psychological sense of cooler temperatures through deep foliage greens, atmospheric shade cyans, and frosted surface overlays that simulate cooling vapor over urban cartography.

### Personality & Emotional Response
- **Reflective & Calming:** Visually lowers user heart rate and perceived heat through airiness and cool-spectrum contrasts.
- **Precision Tech:** Micro-climatic data, UV indexes, and shade percentages are presented with institutional clarity and zero visual clutter.
- **Organic Urbanity:** Combines architectural structural forms with organic, leafy silhouettes.

## Colors

The color palette directly references environmental factors: canopy density, hydraulic cooling, and thermal radiation alerts.

### Primary: Deep Canopy Green (`#0F5132`)
Represents dense tree canopies, optimal thermal shelters, and structural brand authority. Used for primary CTAs, active route states, top navigation anchors, and dominant interactive elements.
- **Emerald Accent (`#198754` / `#20C997`):** Utilized for positive environmental confirmations, high-canopy metric badges, and regenerative paths.

### Secondary: Refreshing Shade & Hydro Cyan (`#0DCAF0`)
Represents shadow paths, cooling mist installations, drinking fountains, and sensory relief. Used for secondary highlights, route shadow overlays, and hydration icons. Paired with an ultra-light tint (`#E0F2FE`) for container fills and floating card backdrops.

### Tertiary: Solar Hazard & Thermal Warning (`#F59E0B` & `#EF4444`)
Reserved strictly for high-exposure alerts, intense UV index metrics, and heat-exhaustion warnings. Amber serves as a caution threshold; Crimson marks extreme sun exposure.

### Neutral: Organic Charcoal & Crisp Slate (`#132A1C`, `#F8FAFC`, `#FFFFFF`)
- **Canvas / Map Tint:** `#F8FAFC` base with semi-translucent `#FFFFFF` overlays (85%–92% opacity with blur) ensuring legible contrast over vivid cartographic layers.
- **Typography Neutral:** Deep forest slate (`#132A1C`) ensures superior outdoor readability under direct sunlight without the harshness of pure black.

## Typography

The type system balances geometric energy with field legibility. `Plus Jakarta Sans` delivers a contemporary, humanistic tone for headlines, thermal data stats, and UI actions. `Inter` provides neutral, hyper-legible body copy optimized for variable lighting conditions and dynamic screen angles during active walking.

### Outdoor Legibility Rules
- Never use font weights below `400` anywhere in the interface.
- Numbers within thermal indicators, shade percentages, and navigation times utilize tabular figures (`tnum`) to prevent jitter when real-time GPS coordinates update.
- Ambient glare compensation: Body text defaults to `#132A1C` with strict minimum contrast ratios of 4.5:1 against glassmorphic backing layers.

## Layout & Spacing

The layout is built for fluid mobile-first mapping overlays. UI components sit as modular floating viewports across a full-bleed map canvas.

### Layout Mechanics
- **Mobile (< 768px):** Single-column contextual stacking anchored to bottom sheets and dynamic top search bars. Margins are fixed at `1rem` with `0.75rem` internal gutters. Safe bottom inset preserves thumb-reach comfort while walking.
- **Tablet & Desktop (≥ 768px):** Left-docked floating panel (width: `400px` fixed) paired with floating floating-action controls on the right canvas. Canvas margin expands to `1.5rem`.
- **Rhythm:** Spacing tokens map strictly to an 8pt base grid (`0.5rem` = 8px, `1rem` = 16px). All card paddings and interactive gap sizes use these intervals to maintain uniform micro-alignment across status indicators.

## Elevation & Depth

Visual depth combines frosted thermal shields with environmental light diffusion rather than heavy opaque shadows.

### Atmospheric Glass Elevation
- **Floating Cartographic Surfaces:** Backdrops use `#FFFFFF` tinted with 12% `#E0F2FE` at 88% opacity, coupled with a 16px background blur (`backdrop-filter: blur(16px)`).
- **Border Definers:** Instead of thick outlines, cards use a 1px composite border (`rgba(255, 255, 255, 0.6)` on top and sides, transitioning to `rgba(15, 81, 50, 0.08)` on bottom) mimicking a light-refracting edge.
- **Shadow Profiles:**
  - **Level 1 (Docked cards, chips):** `0 2px 8px -1px rgba(15, 81, 50, 0.06), 0 1px 3px rgba(0, 0, 0, 0.04)`.
  - **Level 2 (Active navigation sheets, search bars):** `0 12px 32px -4px rgba(15, 81, 50, 0.12), 0 4px 12px -2px rgba(13, 202, 240, 0.08)`.
  - **Level 3 (Modal alerts, heat hazard warnings):** `0 20px 48px -8px rgba(19, 42, 28, 0.18), 0 8px 16px -4px rgba(245, 158, 11, 0.12)`.

## Shapes

The design uses `roundedness: 2` (0.5rem base radius) to convey organic friendliness while preserving structured technological discipline.

### Geometry Specifications
- **Base Cards & Sheets:** `1rem` (16px, `rounded-lg`) corner radii create comfortable resting planes.
- **Floating Search & Bottom Modals:** `1.5rem` (24px, `rounded-xl`) outer edge shaping for natural handheld ergonomic contours.
- **Badges, Route Chips, and Micro-Indicators:** Full pill radius (`9999px`) to emphasize sensory status units (e.g., “84% Sombra”, “23°C Agradável”).

## Components

### Buttons
- **Primary Action (Cool Route / Start Walk):** Deep canopy green (`#0F5132`) background, crisp white text, `0.75rem` vertical padding, `1.5rem` horizontal padding, `0.5rem` border-radius. Active state transitions to `#198754` with a subtle inward compress (`scale(0.98)`).
- **Secondary Action (Hydration / Shelter Filter):** Frosted tint `#E0F2FE` with `#0F5132` text and a subtle `#0DCAF0` border.
- **Sun Alert CTA:** Solid `#F59E0B` with white text, used strictly for route diversion alerts.

### Thermal Status Badges & Chips
- **Shade Optimal:** Pill badge with `#198754` text, `#E8F5E9` background, and an emerald leaf or umbrella icon prefix.
- **Water Refill / Hydro Point:** Pill badge with `#0D6EFD` text, `#E0F2FE` background, displaying distance in meters.
- **Heat Hazard / UV Warning:** Pill badge with `#EF4444` text, `#FEE2E2` background, accompanied by a dynamic pulsing warning dot.

### Floating Route Cards
- Floating cards sit 16px above map level with frosted glass backgrounds.
- Headers contain a side-by-side comparison: **Canopy Route (e.g., 18 min • 82% Sombra • 26°C Percepção)** versus **Fast Route (14 min • 15% Sombra • 34°C Percepção)**.
- Metrics are set with clear typographic tabular hierarchy.

### Input Fields (Location & Sensory Preferences)
- Enclosed inside elevated white-glass bars. 
- Integrated sensory toggles for "Prioritize Shaded Corridors", "Avoid Steep Sun Exposures", and "Show Public Fountains".
- Active focus state produces an emerald outline ring: `0 0 0 3px rgba(32, 201, 151, 0.3)`.

### Lists & Steps
- Step-by-step pedestrian navigation items feature vertical route threads.
- Direct sun segments are colored in muted amber dashed lines, while shade-canopied segments display solid emerald connections.