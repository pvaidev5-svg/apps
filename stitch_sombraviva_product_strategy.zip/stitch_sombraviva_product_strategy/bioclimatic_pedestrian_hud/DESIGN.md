---
name: Bioclimatic Pedestrian HUD
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#414844'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#727974'
  outline-variant: '#c1c8c2'
  surface-tint: '#456556'
  primary: '#001e12'
  on-primary: '#ffffff'
  primary-container: '#133326'
  on-primary-container: '#7a9c8b'
  inverse-primary: '#abcebc'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#261400'
  on-tertiary: '#ffffff'
  tertiary-container: '#422700'
  on-tertiary-container: '#cf8400'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c7ebd7'
  primary-fixed-dim: '#abcebc'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#2d4d3f'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
  canopy-deep: '#1D4333'
  canopy-leaf: '#22C55E'
  mint-surface: '#E8F5E9'
  mint-subtle: '#D1FAE5'
  canvas-limestone: '#F8FAFC'
  thermal-warning: '#EF4444'
  acoustic-calm: '#06B6D4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
  data-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a restorative, sensory-first digital companion tailored for urban pedestrians navigating microclimates, thermal stress, and sensory overload. Moving away from aggressive, vehicle-centric navigation paradigms focused purely on speed, the visual tone prioritizes human wellbeing, somatic ease, and scientific rigor. 

The aesthetic blends Modern Humane Minimalism with organic environmental layers. Interfaces must evoke immediate thermal relief: clean limestone-tinted surfaces counteract urban glare, deep forest greens provide grounded authority and legibility, and refreshing leafy accents communicate vibrancy and protection. Micro-interactions are light, calm, and distraction-free, engineered specifically for high outdoor ambient daylight where glanceability and minimal cognitive load are essential.

## Colors

The color system is calibrated for legibility under bright outdoor sunlight and rapid environmental assessments.

- **Primary (`#133326`)**: Deep Forest Green. Forms the structural foundation, prominent headers, dark buttons, and active route lines. Provides extreme contrast without harshness.
- **Secondary (`#10B981`)**: Leaf Green. Signifies optimal bioclimatic comfort, dense tree canopy corridors, active pedestrian movement, and high shade percentages.
- **Tertiary (`#F59E0B`)**: Solar Amber. Used strictly for contextual thermal stress, high UV indexes, unshaded segments, and data points awaiting community verification.
- **Neutral (`#0F172A`)**: Slate Black. Supplies structural type contrast, high-priority labels, and map landmarks.

### Extended Environmental Tokens
- **`mint-surface` (`#E8F5E9`)** & **`mint-subtle` (`#D1FAE5`)**: Soft, cooling background fills for sensor badges, selected route cards, and oasis markers.
- **`canvas-limestone` (`#F8FAFC`)**: Glare-reduced daylight background canvas replacing pure eye-straining white.
- **`thermal-warning` (`#EF4444`)**: Critical heat stress corridors and severe sun exposure alerts.
- **`acoustic-calm` (`#06B6D4`)**: Low-decibel acoustic corridors and quiet paths under 65 dB.

## Typography

The typography is built around Plus Jakarta Sans, combining geometric structure with humanist warmth and open counters. This ensures instant scanning of street names, walking times, and thermal metrics even while walking under shifting lighting conditions.

- **Headlines**: Weighted heavily (`700` and `800`) to anchor floating map sheets, route summaries, and bioclimatic alerts.
- **Body**: Calibrated for comfortable narrative reading, micro-prompt questions, and accessibility directions.
- **Labels & Micro-data**: Tightly tracked, uppercase or medium-weight values designed for compact microclimate HUD indicators (e.g., `85% SOMBRA`, `62 dB`, `UV 3`).
- **Data Metrics**: Elevated statistical tokens dedicated to immediate telemetry comparisons across trip routes.

## Layout & Spacing

The interface utilizes a modular, fluid column grid tailored for high-density spatial cartography overlaid with floating ergonomic controls.

- **Mobile Viewports (<768px)**: 4-column layout with 16px (`1rem`) outer canvas margins and 12px (`0.75rem`) gutters. Overlays, route options, and urban oasis checks dock as bottom sheets with comfortable thumb zones.
- **Tablet / Desktop Viewports (≥768px)**: 12-column layout with 24px (`1.5rem`) outer canvas margins and 16px (`1rem`) gutters. The map acts as an edge-to-edge canvas with floating floating utility panels docking to the left.
- **Touch Spacing**: Interactive tap targets (e.g., feedback chips, route mode selectors) must provide at least 48px height with a minimum spacing gap of `space-sm` (8px) to prevent misclicks on the go.

## Elevation & Depth

Visual hierarchy uses translucent surfaces, fine tinted outlines, and ambient shadows to create tactile layers above the interactive map canvas.

- **Level 0 (Basemap & Polygon Layers)**: Completely flat map canvas containing building shadows, sun azimuth vectors, and NDVI canopy polygons.
- **Level 1 (Docked Surfaces & Route Cards)**: Surface color `#FFFFFF` with an ambient diffused shadow: `0px 4px 20px -2px rgba(15, 23, 42, 0.06)`, bounded by a 1px border of `rgba(15, 23, 42, 0.08)`.
- **Level 2 (Floating Action Hubs & POI Chips)**: Frosted glass finish using `backdrop-filter: blur(12px)`, background `rgba(248, 250, 252, 0.88)`, and shadow `0px 8px 30px -4px rgba(19, 51, 38, 0.12)`.
- **Level 3 (Modal Prompts & Urgent Thermal Alerts)**: Raised elevated sheets with shadow `0px 16px 40px -6px rgba(15, 23, 42, 0.18)` and tinted border `rgba(19, 51, 38, 0.12)`.

## Shapes

The design system adopts a balanced, approachable curvature model (`level 2`), evoking natural organic contours such as leaves, rounded stones, and smooth street furniture.

- Standard buttons, text fields, and list rows use an 8px (`0.5rem`) radius.
- Cards, bottom sheets, and route selector containers use a 16px (`1rem`) radius (`rounded-lg`).
- Floating search panels, check-in dialogs, and large bottom sheets use a 24px (`1.5rem`) radius (`rounded-xl`).
- Sensor pill badges, status tags, and one-tap quick-reply validation targets are rendered as full pills (`9999px`).

## Components

### Buttons
- **Primary Action (e.g., "Iniciar Trajeto")**: Solid `#133326` background, `#FFFFFF` text, 48px height, 12px horizontal padding, 8px radius. Active state scales to `0.98`.
- **Secondary / Refreshing**: `#E8F5E9` background with `#133326` text, subtle border `1px solid #D1FAE5`.
- **Sensory Floating Button (FAB)**: 56px circular or pill-shaped floating container with 12px blur backdrop, containing primary icons (e.g., water oasis pinpoint, 2-click report).

### Environmental Chips & HUD Pills
- **Shade Chip**: Pill container featuring a `#E8F5E9` background, `#1D4333` text, and a canopy leaf icon with dynamic metric values (e.g., `85% Sombra`).
- **Thermal Alert Chip**: `#FEF3C7` background with `#B45309` text, warning icon, and UV index indicator.
- **Acoustic Chip**: `#CFFAFE` background with `#0E7490` text displaying real-time decibel thresholds (e.g., `< 65 dB`).

### Route Selection Cards
- Card container with `rounded-lg` (16px), 16px internal padding, and border `1px solid rgba(15, 23, 42, 0.08)`.
- Features route strategy headline ("Sombra Máxima", "Equilíbrio Inteligente", "Mais Rápida"), time delta tag ("+3 min"), and horizontal microclimate telemetry bar comparing shade, temperature, and quietness. Selected state applies a 2px outline in `#10B981` with a `mint-surface` background tint.

### Quick-Validation Pills (Zero-Friction Feedback)
- Monolithic tap-friendly pills for instant reporting (e.g., `[Sim, fresca]`, `[Sem água]`, `[Calçada quente]`). 
- Default: `#FFFFFF` fill with `1px solid #CBD5E1`. On tap: Instant fill to `#133326` with `#FFFFFF` text and haptic confirmation.

### Input Fields
- Height 48px, rounded 8px radius, background `#FFFFFF`, border `1px solid #CBD5E1`.
- Focus ring: `2px solid #10B981` with soft offset shadow `0 0 0 3px rgba(16, 185, 129, 0.15)`.

### Checkboxes & Segmented Controls
- Segmented switches toggle map overlays (Canopy NDVI, Extruded Shadows, Drinking Water Fountains, Quiet Corridors). Selected state utilizes an animated soft pill in `#133326` with white text.