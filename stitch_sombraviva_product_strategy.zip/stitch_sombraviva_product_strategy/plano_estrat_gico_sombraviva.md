# SombraViva — Plano Estratégico de Produto & Navegação Sensorial

> **Versão:** 1.0 — Documento de Estratégia de Produto  
> **Status:** Aprovado para Validação / Fase de Descoberta  
> **Público-Alvo:** Equipes de Engenharia, Design de Produto, Investidores e Stakeholders Urbanos

---

## 1. Análise de Mercado & Oportunidade

### 1.1 Gaps Estruturais nos Mapas Tradicionais
Aplicativos consolidados (Google Maps, Apple Maps, Waze) foram historicamente arquitetados sob o paradigma automotivo ou de eficiência utilitária pura: **Menor Tempo ($t$) vs. Menor Distância ($d$)**. 

Quando aplicados ao pedestre urbano, esse modelo apresenta falhas críticas:
- **Cegueira Microclimática:** Ignoram a exposição solar direta, ilhas de calor urbano e radiação térmica acumulada pelo asfalto e concreto.
- **Poluição Sonora e Sobrecarga Sensorial:** Rotas priorizam avenidas de tráfego intenso com calçadas estreitas e ruído acima de 75 dB, inviabilizando caminhadas tranquilas.
- **Invisibilidade da Infraestrutura de Suporte:** Não mapeiam a presença de bebedouros públicos, bancos arborizados, banheiros acessíveis ou estabelecimentos com "refúgio climático" (ar-condicionado livre).

### 1.2 Tendências Macroeconômicas e Climáticas
- **Aquecimento Global & Ilhas de Calor:** Cidades latino-americanas e globais enfrentam recordes frequentes de ondas de calor. Em capitais como São Paulo, Rio de Janeiro, Sevilha ou Phoenix, caminhar sob sol de meio-dia representa risco médico (insolação, desidratação, síncope).
- **Cidades de 15 Minutos & Mobilidade Ativa:** Políticas públicas de incentivo ao pedestrismo e micromobilidade demandam rotas humanizadas.
- **Saúde Mental e Neurodivergência:** Crescimento da busca por itinerários calmos para pessoas com sensibilidade sensorial (TEA, TDAH, ansiedade social).

### 1.3 Segmentos de Usuários & Casos de Uso Prioritários

| Persona | Perfil | Caso de Uso Principal | Critério de Sucesso |
| :--- | :--- | :--- | :--- |
| **Mariana, 68 anos** | Idosa, hipertensa, realiza pequenas tarefas matinais a pé. | Caminhar até a farmácia e padaria sem sofrer exaustão térmica ou falta de ar. | Rota contínua sob sombras e presença de bancos para pausa a cada 300m. |
| **Lucas, 29 anos** | Desenvolvedor remoto, neurodivergente / focado em bem-estar. | Deslocamento para coworking ou pausas de almoço sem estresse auditivo. | Rota "Caminho Silencioso" com menos decibéis e ruas secundárias arborizadas. |
| **Camila, 34 anos** | Mãe com carrinho de bebê e criança pequena. | Levar o filho à praça no meio da tarde. | Itinerário com calçadas sombreadas e bebedouro/banheiro funcional garantido. |
| **Carlos, 42 anos** | Trabalhador que combina metrô + 25 minutos de caminhada formal. | Chegar ao escritório sem camisa encharcada de suor sob sol de 33°C. | Rota "Sombra Máxima", mesmo que custe 4 a 6 minutos a mais de caminhada. |

---

## 2. Proposta de Valor & Posicionamento

### 2.1 Declaração de Posicionamento
> *"Para pedestres urbanos que sofrem com o calor extremo e o estresse sonoro das cidades, o **SombraViva** é a primeira plataforma de navegação ativa que otimiza rotas pela qualidade bioclimática e sensorial do trajeto. Ao contrário de mapas tradicionais focados apenas em minutos e metros, nós calculamos sombras em tempo real, níveis de ruído e pontos de acolhimento comunitário para tornar o ato de caminhar saudável, fresco e digno."*

### 2.2 Matriz Competitiva

```
             Foco Sensorial / Bioclimático Alto
                           │
                           │       [★ SombraViva]
                           │
                           │
      Citymapper           │
      (Intermodal)         │       Walkonomics / Go-Gentle
                           │       (Projetos Acadêmicos/Restritos)
───────────────────────────┼───────────────────────────
  Foco Utilitário Puro     │     Foco Utilitário Puro
  (Baixo Alcance Global)   │     (Escala Massiva)
                           │
      Komoot / Strava      │       Google Maps / Waze / Apple Maps
      (Trilhas/Esportes)   │       (Carros + A-to-B Rápido)
                           │
             Foco Sensorial / Bioclimático Baixo
```

### 2.3 Pilares de Experiência (Value Drivers)
1. **Conforto Térmico Dinâmico:** Algoritmo que projeta sombras preditivas com base no azimute/elevação solar e no tecido edificado tridimensional.
2. **Descompressão Acústica:** Roteamento por vias arborizadas residenciais em vez de corredores viários ruidosos.
3. **Rede de Cuidado Urbano:** Democratização de oásis urbanos (água, sombra, ar-condicionado solidário).

---

## 3. Arquitetura de Features & Roadmap

```
+---------------------------------------------------------------------------------+
|                                 SombraViva                                      |
+---------------------------------------------------------------------------------+
          |                                       |
    [Módulo de Rotas]                      [Módulo Comunitário]
    - Rota Sombra Máxima                   - Mapeamento de Oásis (Água/Bancos)
    - Caminho Silencioso                   - Validação Rápida ("Esse ponto existe?")
    - Trajeto com Pontos de Apoio          - Alertas de Ocorrência (Árvore caída/Sol)
          |                                       |
    [Engine Microclimática]                [Perfil & Conforto Pessoal]
    - Projeção Solar + Mesh 3D             - Modo Sensibilidade Máxima (Calor/Ruído)
    - Índice de Conforto Térmico (UTCI)    - Estimativa de Suor e Economia de UV
```

### 3.1 Priorização de Funcionalidades

#### Fase 1: MVP (Mínimo Produto Viável — 0 a 4 Meses)
- **Cálculo de Sombra Estática-Dinâmica:** Simulação de sombras baseada em vetores solares (hora do dia) cruzados com pegadas de edifícios (OpenStreetMap + dados abertos de altura).
- **Três Perfis de Roteamento:**
  - *Sombra Máxima:* Prioriza calçadas com cobertura solar mínima de 70%.
  - *Equilíbrio Inteligente:* Rota que tolera até +5 minutos em troca de 50%+ de sombra.
  - *Mais Rápida:* Rota padrão como baseline de comparação.
- **Painel de Microclima do Trajeto:** Exibição do % de exposição solar, índice UV estimado e ganho de sombra comparado à rota direta.
- **Oásis Comunitários (Read-Only com Report Básico):** Exibição de bebedouros públicos e parques catalogados via dados abertos municipais.

#### Fase 2: Expansão (5 a 9 Meses)
- **Caminho Silencioso:** Inclusão de camadas acústicas com base no fluxo viário histórico e zoneamento municipal.
- **Pontos de Apoio e Refúgio Colaborativos:** Capacidade de usuários cadastrarem e validarem bebedouros, comércios com água/AC livre e bancos funcionais.
- **Ajuste por Lado da Calçada:** Roteamento granular identificando se a calçada leste ou oeste da rua possui sombra no horário da navegação.
- **Feedback Passivo do Sensor:** Uso de giroscópio e sensores ambientais do smartphone para inferir paradas e conforto.

#### Fase 3: Maturidade & B2B/Gov (10 a 18 Meses)
- **Simulação de Copas de Árvores (LIDAR e Satélite):** Integração de densidade de dossel vegetal via sensoriamento remoto (Sentinel/Landsat) para calcular sombras naturais.
- **SombraViva Analytics for Cities:** Dashboard para secretarias de urbanismo visualizarem desertos de sombra e priorizarem plantio de árvores e instalação de bebedouros.
- **API Pública / SDK para Integrações:** Plugins para apps de saúde (ex: Apple Health, Google Fit) integrando calor suportado durante atividades.

---

## 4. Modelo de Dados & Arquitetura Técnica

```
  +----------------------+      +----------------------+      +----------------------+
  |  Dados Geográficos   |      |   Dados Físicos &    |      |  Sensores & Dados    |
  |  - OpenStreetMap 2D  |      |   Solares            |      |  Comunitários        |
  |  - Modelos 3D / LOD1 |      |  - Posicionamento    |      |  - Sensores IoT      |
  |  - Cadastro Arbóreo  |      |    Solar (SunCalc)   |      |  - Crowdsourcing     |
  +----------+-----------+      +----------+-----------+      +----------+-----------+
             |                             |                             |
             +--------------------+--------+-----------------------------+
                                  |
                                  v
                    +-----------------------------+
                    |  Motor de Grafos Sensoriais |
                    |  - Valhalla / pgRouting     |
                    |  - Custom Cost Functions    |
                    |    (Weight = d + k1*Sun +   |
                    |              k2*Noise)      |
                    +--------------+--------------+
                                   |
                                   v
                    +-----------------------------+
                    | SombraViva Mobile Client    |
                    | - Renderização MapLibre     |
                    | - Camada Visual de Sombras  |
                    +-----------------------------+
```

### 4.1 Fontes de Dados e Pipeline de Ingestão
1. **Geometria dos Edifícios & Alturas:** OpenStreetMap (`building:levels`, `height`), dados abertos municipais (LOD1/LOD2 3D geodata) e modelos digitais de elevação (DEM).
2. **Cálculo Solar em Tempo Real:** Algoritmo astronômico (SunCalc/NOAA Solar Calculator) calculando Azimute e Ângulo Zenital para a coordenada geográfica e fuso horário exato do usuário a cada minuto.
3. **Cálculo da Projeção de Sombras:** Extrusão dos polígonos dos edifícios no vetor de incidência luminosa, projetando polígonos de sombra no plano das calçadas através de operações de geometria espacial (PostGIS / Turf.js no cliente).
4. **Camada de Vegetação (Copas de Árvores):** Dados do inventário arbóreo municipal enriquecidos com processamento NDVI (Normalized Difference Vegetation Index) de imagens de satélite.

### 4.2 Função de Custo de Roteamento Ponderada
Para calcular o melhor caminho no grafo de pedestres, a aresta do grafo $e$ tem seu custo definido por:

$$C(e) = L(e) \cdot \left(1 + \alpha \cdot S(e, t) + \beta \cdot N(e) + \gamma \cdot D(e)\right) - \delta \cdot A(e)$$

Onde:
- $L(e)$: Comprimento linear do segmento de calçada.
- $S(e, t) \in [0, 1]$: Taxa de exposição solar direta no horário $t$ ($0 = 100\%$ sombra, $1 = 100\%$ sol escaldante).
- $N(e) \in [0, 1]$: Índice de ruído urbano medido/estimado.
- $D(e) \in [0, 1]$: Declividade da via (penalidade para ladeiras em dias quentes).
- $A(e)$: Bônus pela presença de pontos de apoio imediatos (bebedouros, bancos).
- $\alpha, \beta, \gamma, \delta$: Pesos customizáveis definidos pelo filtro do usuário.

---

## 5. Estratégia de Adoção & Inteligência Comunitária

O mapeamento de oásis urbanos e a validação do microclima dependem da comunidade sem sobrecarregar quem está apenas caminhando.

### 5.1 Mecanismo de Microvalidação com "Fricção Zero"
- **Check-ins Passivos & One-Tap Prompt:** Ao detectar que o usuário parou próximo a um bebedouro ou banco catalogado por mais de 45 segundos, o app dispara um prompt sutil pós-caminhada:
  > *"O bebedouro da Praça Roosevelt estava funcionando com água gelada?"*  
  > `[Sim, ótima] [Sem água / Quebrado] [Não usei]`
- **Relato de 2 Cliques:** Botão flutuante na navegação com tags de feedback rápido:  
  `[Ar-condicionado público]` | `[Sombra densa agradável]` | `[Calçada quente / Sem árvore]`

### 5.2 Gamificação Intrínsica & Cidadania Urbana
- **"Guardiões da Sombra":** Reconhecimento de voluntários que mapeiam e validam novos pontos de apoio. Badges digitais e rankings de bairros mais bem mapeados.
- **Relatório de Impacto Pessoal:** Em vez de pontuações fúteis, mostrar métricas reais de bem-estar acumuladas:
  - *"Neste mês, o SombraViva poupou você de 4,2 km de caminhada sob sol direto."*
  - *"Você evitou aproximadamente 120 minutos de ruído intenso acima de 80 dB."*

---

## 6. Modelo de Negócios & Sustentabilidade Financeira

O compromisso inegociável do produto é manter a navegação de pedestres **100% gratuita, sem paywall em rotas saudáveis e sem invasão de privacidade**.

```
+-----------------------------------------------------------------------------------+
|                           Modelo de Sustentabilidade                              |
+-----------------------------------------------------------------------------------+
|  1. B2G (Gov & Cidades)       |  2. B2B Oásis Patrocinados   |  3. ESG & Mobilidade |
|  - SombraViva Analytics       |  - Cafés, livrarias e lojas  |  - Integração com    |
|  - Mapeamento de calor        |    como pontos de refúgio    |    planos corporativos|
|    para secretarias de obras  |    térmico / água livre      |    de saúde e bem-estar|
+-----------------------------------------------------------------------------------+
```

### 6.1 Fontes de Receita Viáveis

1. **SombraViva City Analytics (B2G - Setor Público):**
   - Venda de relatórios anonimizados e mapas de calor de caminhabilidade para secretarias municipais de Urbanismo, Meio Ambiente e Saúde.
   - Fornece diagnóstico exato de onde faltam árvores, onde ocorrem gargalos de hidratação pública e quais calçadas geram maior vulnerabilidade a idosos e crianças.
2. **Oásis Urbanos Parceiros & Comércio Local (B2B Hyperlocal):**
   - Estabelecimentos comerciais (cafés, drogarias, shoppings) podem se cadastrar como "Pontos de Refúgio Térmico" certificados, oferecendo água gratuita ou ar-condicionado.
   - Destaque sutil e contextual no mapa no momento em que o usuário busca abrigo térmico, atraindo fluxo natural sem anúncios invasivos ou banners agressivos.
3. **Parcerias com Planos de Saúde & Seguradoras (B2B ESG):**
   - Convênios com operadoras de saúde focadas em prevenção geriátrica e incentivo à atividade física segura para hipertensos e cardíacos durante picos de calor.

---

## 7. Riscos, Desafios & Planos de Mitigação

| Categoria | Risco Identificado | Impacto | Estratégia de Mitigação |
| :--- | :--- | :--- | :--- |
| **Técnico** | Falta de dados 3D de edifícios em bairros periféricos ou cidades médias. | Alto | Pipeline híbrido: onde não houver modelos 3D vetoriais, inferir altura média por zoneamento urbano e focar em dados de densidade de copas de satélite (NDVI global). |
| **Operacional** | Vandalismo ou obsolescência de bebedouros e pontos de apoio mapeados. | Médio | Sistema de pontuação de confiabilidade: pontos sem validação recente por 30 dias perdem prioridade e exibem etiqueta *"A confirmar status"*. |
| **UX / Adoção** | Rotas de sombra que resultem em distâncias longas demais ou ruas perigosas. | Crítico | **Trava de Segurança & Proporção:** Nunca sugerir rotas com acréscimo superior a 25% de tempo sem consentimento explícito. Integração com iluminação pública e ruas ativas para evitar becos escuros. |
| **Privacidade** | Risco de rastreamento de deslocamentos individuais de usuários. | Alto | Processamento de rota e telemetria prioritariamente on-device; dados de multidão agregados e anonimizados por hexágonos espaciais (H3 Uber) sem vínculo a IDs. |

---

## 8. Conclusão & Próximos Passos de Execução

O **SombraViva** responde a uma crise urgente e crescente de habitabilidade nas metrópoles. Ao colocar o conforto bioclimático e a sensibilidade humana no centro da tecnologia de geolocalização, a plataforma transforma a caminhada urbana de uma prova de resistência em uma experiência de saúde, prazer e reconexão com a cidade.

**Próximos Passos:**
1. Validação de protótipo de projeção solar vetorial em um recorte piloto de 4 km² (ex: Região Central / Paulista em SP ou Centro do Rio).
2. Testes de usabilidade A/B com usuários idosos e trabalhadores em dias de temperatura acima de 30°C.
3. Apresentação do piloto a laboratórios de inovação urbana (ex: GovTechs, Smart Cities Hubs).